'''
Created on Dec 24, 2019

@author: boogie
'''
from tinyxbmc import const
from tinyxbmc import net

import urllib


def get_visitorid():
    return "35009a79-1a05-49d7-b876-2b884d0f825b"


def track(module, container, method, args, kwargs):
    page = "http://tinyxbmc.com/%s/%s/%s/" % (module, container, method)
    for arg in args:
        page += str(arg) + "/"
    page += "?" + urllib.urlencode(kwargs)
    url = 'https://ssl.google-analytics.com/collect'
    payload = {
        'v': 1,
        'tid': 'UA-154866073-1',
        'cid': get_visitorid(),
        't': 'screenview',
        'an': 'tinyxbmc',
        'av': const.VERSION,
        'cd': page,
        'dl': page,
    }

    ua = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:11.0) Gecko/20100101 Firefox/11.0'
    resp = net.http(url, data=payload, useragent=ua, method="POST")
    pass
