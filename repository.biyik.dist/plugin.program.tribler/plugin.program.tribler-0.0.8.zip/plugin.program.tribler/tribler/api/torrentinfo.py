'''
Created on 26 Mar 2020

@author: boogie
'''
import json
import hashlib
import bencode
import binascii

from . import common


class torrentinfo:
    @staticmethod
    def get(uri, hops=None, infohash=None):
        if not uri:
            uri = common.makemagnet(infohash)
        kwargs = {"uri": uri}
        if hops:
            kwargs["hops"] = hops
        resp = common.call("GET", "torrentinfo", **kwargs)
        if resp and resp.get("metainfo"):
            print(resp["metainfo"])
            metainfo = json.loads(binascii.unhexlify(resp["metainfo"].encode()))
            metainfo["info"]["pieces"] = binascii.unhexlify(metainfo["info"]["pieces"].encode())
            metainfo["infohash"] = hashlib.sha1(bencode.encode(metainfo['info'])).hexdigest()
            return metainfo
        else:
            return resp
