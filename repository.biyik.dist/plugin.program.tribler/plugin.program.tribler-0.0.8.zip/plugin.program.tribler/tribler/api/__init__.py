from tribler.api.download import download
from tribler.api.search import search
from tribler.api.metadata import metadata
from tribler.api.channel import channel
from tribler.api.remote import remote

from tribler.api.common import config, call, makemagnet
