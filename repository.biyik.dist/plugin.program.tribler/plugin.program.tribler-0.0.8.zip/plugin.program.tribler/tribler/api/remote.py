'''
Created on 26 Mar 2020

@author: boogie
'''
from tinyxbmc import gui

from tribler.api import common
from tribler import defs

import threading
import time


class remote:
    @staticmethod
    def query(txt_filter=None, channel_pk=None, metadata_type="torrent", sort_by="updated", sort_desc=1, timeout=None, max_results=None, hide_xxx=0):
        loop_timeout = defs.GIGA_TIMEOUT
        e = common.event(timeout or loop_timeout)
        state = {"start": None, "stop": False, "queries": 0, "results": []}

        def progress():
            progress = gui.progress("Querying GigaChannel")
            state["start"] = time.time()
            while True:
                time.sleep(0.1)
                elapsed = time.time() - state["start"]
                if timeout is not None and elapsed > timeout or \
                        progress.iscanceled() or \
                        max_results is not None and len(state["results"]) >= max_results:
                    e.response.close()
                    state["stop"] = True
                    break
                else:
                    if timeout is not None:
                        percent = int(100 * elapsed / timeout)
                    else:
                        percent = int(100 * (elapsed % loop_timeout) / loop_timeout)
                        if elapsed > loop_timeout:
                            percent = 100
                            e.response.close()
                    progress.update(percent, "Found %s Results in %s queries. %s" % (len(state["results"]),
                                                                                     state["queries"],
                                                                                     "MAX RESULTS: " + str(max_results) if max_results else ""))

        threading.Thread(target=progress).start()
        while True:
            e.prepare()
            if state["stop"]:
                break
            common.call("PUT", "remote_query",
                        sort_by=sort_by,
                        sort_desc=sort_desc,
                        txt_filter=txt_filter,
                        channel_pk=channel_pk,
                        metadata_type=metadata_type)
            state["queries"] += 1
            for ev in e.iter("remote_query_results"):
                results = ev.get("results", [])
                if results:
                    state["results"].extend(results)
                    break
            if timeout is None:
                state["start"] = time.time()
        return state["results"]
