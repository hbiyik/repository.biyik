'''
Created on 2 Haz 2020

@author: boogie
'''
from tinyxbmc import addon
from tinyxbmc import collector
from tribler import core
from tribler import defs
import subprocess
import signal
import sys
import os

PORT = 8889
KEY = "12345678"

if False:
    pdevpath = "/home/boogie/local/eclipse/plugins/org.python.pydev.core_7.5.0.202001101138/pysrc/"
    sys.path.append(pdevpath)
    import pydevd  # @UnresolvedImport
    pydevd.settrace(stdoutToServer=True, stderrToServer=True, suspend=False)


class Service(addon.blockingloop):
    def oninit(self):
        self.triblerd = None
        self.wait = 1
        if not self.checkcfg():
            self.close()
            return
        self.binary = core.update()
        if not self.binary:
            self.close()
            return
        env = os.environ.copy()
        # env["_MEIPASS2"] = core.MEI_DIR
        # env["TEMP"] TO-DO: fix this
        with collector.LogException("Tribler Service", ignore=True):
            self.triblerd = subprocess.Popen([self.binary,
                                              "-s", core.STATE_DIR,
                                              "-p", str(PORT),
                                              "-k", KEY], stderr=subprocess.STDOUT, env=env, stdout=subprocess.PIPE)

    def checkcfg(self):
        settings = addon.kodisetting(defs.ADDONID)
        if settings.getstr("conmode") == "Local":
            settings.set("address", "http://127.0.0.1:%s" % PORT)
            settings.set("apikey", KEY)
            return True
        return False

    def onloop(self):
        # self.checkcfg()
        pass

    def onclose(self):
        if self.triblerd:
            self.triblerd.terminate()
            self.triblerd.send_signal(signal.SIGINT)
            self.triblerd.wait()
            self.triblerd = None


Service()
